=======================================================================
NAWABI FOOD CORNER - APPLE macOS CASHIER POS STATION
(MacBook, Mac Mini, iMac - M1/M2/M3/M4 & Intel)
=======================================================================

FASTEST & EASIEST 1-CLICK LAUNCH (ZERO SECURITY BLOCKS):
👉 Simply double-click:
   Nawabi-Food-Corner-POS.html

   macOS NEVER blocks .html files with Gatekeeper!
   It will open IMMEDIATELY in Safari, Chrome, or Edge with:
   - All 17 live menu categories & 88 dishes
   - 100% offline billing & cash drawer shift management
   - Instant 80mm thermal receipt printing

-----------------------------------------------------------------------
DEDICATED APP WINDOW LAUNCH (Using Launch-POS-Mac.command):
If you double-click 'Launch-POS-Mac.command' and macOS shows:
"Apple could not verify Launch-POS-Mac is free of malware..."

This is standard macOS security for downloaded script files.
To open it:
Method 1 (Easiest - 1 click):
1. Right-Click (or Control + Click) on 'Launch-POS-Mac.command'
2. Click "Open"
3. Click "Open" on the dialog box.
   macOS will remember this permanently and open instantly thereafter!

Method 2 (Terminal):
Open Terminal and paste:
   xattr -cr ~/Downloads/Nawabi-Food-Corner-POS-Mac
=======================================================================
