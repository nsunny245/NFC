=======================================================================
NAWABI FOOD CORNER - APPLE macOS POS TERMINAL (OFFLINE & ONLINE)
=======================================================================

Compatible with: macOS Monterey, Ventura, Sonoma, Sequoia (Apple Silicon M1-M4 & Intel)

HOW TO RUN:
1. Double-click "Launch-POS-Mac.command" to start billing immediately!
2. (Optional) Drag "Launch-POS-Mac.command" or "pos-offline-kiosk.html" 
   to your Dock or Applications folder for 1-click access.

OFFLINE CAPABILITIES:
- If internet is active: Connects directly to the live Cloud POS Hub.
- If internet drops or is disconnected: Automatically opens the local 
  offline kiosk. You can take orders, calculate cash/change, and print 
  80mm thermal receipts completely offline!
- When internet returns: Click "⚡ SYNC CLOUD" to push all offline sales 
  straight to the central restaurant server database.

THERMAL PRINTER SETUP:
- Select your 80mm ESC/POS printer in macOS Printers & Scanners.
- Print dialog will automatically open formatted for 80mm roll paper.
