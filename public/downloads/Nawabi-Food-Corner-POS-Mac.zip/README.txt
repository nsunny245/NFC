=======================================================================
NAWABI FOOD CORNER - APPLE macOS POS TERMINAL (OFFLINE & ONLINE)
=======================================================================

Compatible with: macOS Monterey, Ventura, Sonoma, Sequoia (Apple Silicon M1-M4 & Intel)

HOW TO RUN ON MAC:
Option 1 (Fastest & 100% Guaranteed - Zero Gatekeeper Prompts):
  👉 Double-click "Nawabi-Food-Corner-POS.html"!
  - Opens instantly in Safari or Chrome.
  - Never blocked by macOS security!
  - 100% works offline without internet.
  - Direct 80mm ESC/POS thermal printing.
  - Takes Dine-In, Takeaway, and Delivery orders.
  - Saves orders locally and syncs to cloud whenever online!

Option 2 (Standalone Window Runner):
  👉 If you run "Launch-POS-Mac.command":
  - If macOS shows "Apple could not verify", simply:
    1. Right-click (or Control-click) "Launch-POS-Mac.command"
    2. Click "Open" from the menu
    3. Click "Open" in the dialog box.
    (macOS will remember your choice and open it directly next time).
