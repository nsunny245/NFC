#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOCAL_KIOSK="file://$DIR/pos-offline-kiosk.html"
ONLINE_URL="https://nawabifoodcorner.com/pos"

echo "======================================================================="
echo "   NAWABI FOOD CORNER - APPLE macOS POS TERMINAL (OFFLINE & ONLINE)    "
echo "======================================================================="
echo ""
echo "Checking server connectivity..."

# Check internet connectivity
if ping -c 1 8.8.8.8 >/dev/null 2>&1; then
    TARGET_URL="$ONLINE_URL"
    echo "[ONLINE] Connected! Opening Nawabi POS Cloud Station..."
else
    TARGET_URL="$LOCAL_KIOSK"
    echo "[OFFLINE] Network down. Opening Nawabi POS Standalone Kiosk..."
fi

# Try launching in dedicated Chrome/Edge app window mode if installed
if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "/Applications/Google Chrome.app" --args --app="$TARGET_URL" --start-maximized
elif [ -d "/Applications/Microsoft Edge.app" ]; then
    open -na "/Applications/Microsoft Edge.app" --args --app="$TARGET_URL" --start-maximized
elif [ -d "/Applications/Brave Browser.app" ]; then
    open -na "/Applications/Brave Browser.app" --args --app="$TARGET_URL" --start-maximized
else
    open "$TARGET_URL"
fi
exit 0
