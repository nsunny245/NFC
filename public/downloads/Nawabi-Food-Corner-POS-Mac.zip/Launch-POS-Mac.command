#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
# Remove quarantine attributes automatically
xattr -d com.apple.quarantine "$0" 2>/dev/null
xattr -cr "$DIR" 2>/dev/null

LOCAL_KIOSK="file://$DIR/Nawabi-Food-Corner-POS.html"
echo "======================================================================="
echo "   NAWABI FOOD CORNER - APPLE macOS POS TERMINAL (OFFLINE & ONLINE)    "
echo "======================================================================="
echo ""
echo "Launching Nawabi POS Station..."

# Check if Chrome or Edge exists to run in clean standalone app window
if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "/Applications/Google Chrome.app" --args --app="$LOCAL_KIOSK" --start-maximized
elif [ -d "/Applications/Microsoft Edge.app" ]; then
    open -na "/Applications/Microsoft Edge.app" --args --app="$LOCAL_KIOSK" --start-maximized
elif [ -d "/Applications/Brave Browser.app" ]; then
    open -na "/Applications/Brave Browser.app" --args --app="$LOCAL_KIOSK" --start-maximized
else
    open "$LOCAL_KIOSK"
fi
exit 0
