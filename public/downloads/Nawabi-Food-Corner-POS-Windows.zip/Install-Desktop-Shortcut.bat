@echo off
title Nawabi Food Corner - Create Desktop Shortcut
echo =======================================================================
echo     NAWABI FOOD CORNER - INSTALL DESKTOP SHORTCUT
echo =======================================================================
echo.
echo Setting up desktop launcher...

set "SCRIPT_PATH=%~dp0Launch-POS-Terminal.bat"
set "ICON_PATH=%~dp0logo.ico"
set "VBS_SCRIPT=%TEMP%\make_nfc_shortcut.vbs"

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%VBS_SCRIPT%"
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\Nawabi Food Corner POS.lnk" >> "%VBS_SCRIPT%"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%VBS_SCRIPT%"
echo oLink.TargetPath = "%SCRIPT_PATH%" >> "%VBS_SCRIPT%"
echo oLink.WorkingDirectory = "%~dp0" >> "%VBS_SCRIPT%"
echo oLink.Description = "Nawabi Food Corner POS Cashier Station" >> "%VBS_SCRIPT%"
echo oLink.IconLocation = "%ICON_PATH%" >> "%VBS_SCRIPT%"
echo oLink.Save >> "%VBS_SCRIPT%"

cscript //nologo "%VBS_SCRIPT%"
if exist "%VBS_SCRIPT%" del "%VBS_SCRIPT%"

echo.
echo =======================================================================
echo  SUCCESS: 'Nawabi Food Corner POS' icon created on your Desktop!
echo  Double-click that icon anytime to launch POS (Works Online and Offline).
echo =======================================================================
echo.
pause
