@echo off
title Install Desktop Shortcut - Nawabi POS
set "SCRIPT=%TEMP%\MakeNawabiShortcut.vbs"
set "TARGET=%~dp0Nawabi-Food-Corner-POS.html"
set "ICON=%~dp0logo.ico"

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%SCRIPT%"
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\Nawabi Food Corner POS.lnk" >> "%SCRIPT%"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%SCRIPT%"
echo oLink.TargetPath = "%TARGET%" >> "%SCRIPT%"
echo oLink.Description = "Nawabi Food Corner POS Cashier Station" >> "%SCRIPT%"
echo oLink.IconLocation = "%ICON%, 0" >> "%SCRIPT%"
echo oLink.Save >> "%SCRIPT%"

cscript //nologo "%SCRIPT%"
del "%SCRIPT%" >nul 2>&1

echo.
echo =======================================================================
echo  SUCCESS! 'Nawabi Food Corner POS' shortcut created on your Desktop!
echo =======================================================================
timeout /t 3
exit
