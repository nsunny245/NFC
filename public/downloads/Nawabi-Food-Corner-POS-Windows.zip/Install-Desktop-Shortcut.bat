@echo off
title Nawabi Food Corner POS - Installer
color 0A

echo =======================================================================
echo       INSTALLING NAWABI FOOD CORNER POS TO WINDOWS DESKTOP
echo =======================================================================
echo.
echo Setting up desktop shortcut with official restaurant icon...

cscript //nologo "%~dp0make_shortcut.vbs"

echo.
echo [SUCCESS] Shortcut created on your Desktop!
echo You can now double-click 'Nawabi Food Corner POS' from your Desktop.
echo.
pause
