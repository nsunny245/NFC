Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\Nawabi Food Corner POS.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
sCurrentDir = oWS.CurrentDirectory
oLink.TargetPath = sCurrentDir & "\Nawabi-Food-Corner-POS.exe"
oLink.IconLocation = sCurrentDir & "\logo.ico, 0"
oLink.Description = "Nawabi Food Corner - Cashier POS Terminal"
oLink.WorkingDirectory = sCurrentDir
oLink.WindowStyle = 3 ' Maximized
oLink.Save
