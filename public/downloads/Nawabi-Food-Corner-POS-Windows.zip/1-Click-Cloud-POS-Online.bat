@echo off
title Nawabi Food Corner - Cloud POS Station
color 0A

echo =======================================================================
echo     NAWABI FOOD CORNER - LIVE CLOUD POS STATION (ONLINE)
echo =======================================================================
echo.
echo Connecting to live cloud hub (Requires active internet connection)...

set "ONLINE_URL=https://nawabifoodcorner.com/pos"
set "USER_DIR=%LOCALAPPDATA%\NawabiPOSProfile"

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%ONLINE_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%ONLINE_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%ONLINE_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%ONLINE_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

start "" "%ONLINE_URL%"
exit
