=======================================================================
NAWABI FOOD CORNER - STANDALONE OFFLINE & CLOUD POS (WINDOWS 7, 8, 10, 11)
=======================================================================

WHAT'S INCLUDED:
1. Nawabi-Food-Corner-POS.html
   - 100% STANDALONE OFFLINE POS CASHIER STATION
   - Exact live restaurant menu (All 17 categories & 88 dishes)
   - Works without internet! Cash drawer till, cart, change return & 80mm thermal receipt printing
   - Double-click to open in ANY browser on any Windows PC (even Windows 7)!

2. 1-Click-Offline-POS-Station.bat
   - Launches the standalone offline station in clean full-screen kiosk window mode (no browser address bar)

3. 1-Click-Cloud-POS-Online.bat
   - Launches the online cloud portal (https://nawabifoodcorner.com/pos)

4. Launch-POS-Terminal.bat
   - Smart launcher: Auto-detects internet connection. If online -> Cloud Hub; if offline -> Offline POS!

5. Install-Desktop-Shortcut.bat
   - Double-click once to put the official Nawabi POS icon right on your Windows Desktop!

=======================================================================
