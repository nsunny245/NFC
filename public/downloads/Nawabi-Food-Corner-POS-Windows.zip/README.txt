=======================================================================
NAWABI FOOD CORNER - STANDALONE CASHIER POS TERMINAL
COMPATIBILITY: WINDOWS 7 (32-bit & 64-bit), WINDOWS 8, WINDOWS 10, WINDOWS 11
=======================================================================

URDU INSTRUCTIONS / اردو ہدایات:
1. 'Install-Desktop-Shortcut.bat' پر ڈبل کلک کریں تاکہ آپ کی کمپیوٹر اسکرین (Desktop) پر آئکن بن جائے۔
2. اب آپ ڈیسک ٹاپ پر موجود 'Nawabi Food Corner POS' آئکن پر ڈبل کلک کر کے کیشئر سسٹم چلا سکتے ہیں۔
3. یہ ونڈوز 7 کے پرانے کمپیوٹرز اور ونڈوز 10/11 دونوں پر یکساں طور پر انتہائی تیز رفتار چلتا ہے۔

ENGLISH INSTRUCTIONS:
1. Double-click 'Install-Desktop-Shortcut.bat' to create a desktop shortcut with the official restaurant logo.
2. Double-click 'Nawabi Food Corner POS' on your Desktop to open the POS terminal in dedicated kiosk app mode (without browser address bars).
3. Connect any 80mm or 58mm USB / Thermal Receipt printer for instant 1-click receipts!

Server Address: https://nawabifoodcorner.com/pos
Helpline: 0347-6824180
