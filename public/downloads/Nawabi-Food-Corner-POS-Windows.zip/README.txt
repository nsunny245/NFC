=======================================================================
NAWABI FOOD CORNER - STANDALONE OFFLINE & ONLINE POS TERMINAL
=======================================================================

Compatible with: Windows 7, Windows 8, Windows 10 (22H2), Windows 11 (32-bit & 64-bit)

HOW TO RUN:
1. Double-click "Launch-POS-Terminal.bat" to start billing immediately!
2. (Optional) Double-click "Install-Desktop-Shortcut.bat" to place a 
   permanent Nawabi POS app icon directly on your Windows Desktop.

OFFLINE CAPABILITIES:
- If internet is active: Connects directly to the live Cloud POS Hub.
- If internet drops or is disconnected: Automatically opens the local 
  offline kiosk. You can take orders, calculate cash/change, and print 
  80mm thermal receipts completely offline!
- When internet returns: Click "⚡ SYNC CLOUD" to push all offline sales 
  straight to the central restaurant server database.

THERMAL PRINTER SETUP:
- Set your 80mm ESC/POS USB or network thermal printer as default printer.
- Page margins: None / Minimum.
- Fits standard 80mm & 58mm thermal receipt paper rolls.
