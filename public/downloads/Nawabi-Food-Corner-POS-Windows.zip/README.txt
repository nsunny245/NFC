=======================================================================
NAWABI FOOD CORNER - STANDALONE OFFLINE & ONLINE POS TERMINAL
=======================================================================

Compatible with: Windows 7, Windows 8, Windows 10 (22H2), Windows 11

HOW TO RUN:
Option 1 (Guaranteed 100% Offline with Zero Internet):
  👉 Double-click "1-Click-Offline-POS-Station.bat"
     OR double-click "Nawabi-Food-Corner-POS.html" directly!
  - Works without internet!
  - Takes Dine-In, Takeaway, and Delivery orders.
  - Calculates cash tendered and change return.
  - Prints 80mm & 58mm thermal receipts.
  - Saves all orders locally on this PC.
  - Click "⚡ SYNC CLOUD" anytime to push offline bills to the restaurant server.

Option 2 (Live Cloud Server):
  👉 Double-click "1-Click-Cloud-POS-Online.bat" to open the live online POS.

Option 3 (Desktop Icon):
  👉 Double-click "Install-Desktop-Shortcut.bat" to put a permanent 
     Nawabi POS icon on your Windows Desktop.
