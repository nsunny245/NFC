@echo off
title Nawabi Food Corner - POS Terminal Station
color 0E

echo =======================================================================
echo     NAWABI FOOD CORNER - OFFLINE/ONLINE CASHIER TERMINAL (WIN 7-11)
echo =======================================================================
echo.
echo Checking connection to restaurant server...

set "LOCAL_KIOSK=%~dp0Nawabi-Food-Corner-POS.html"
set "ONLINE_URL=https://nawabifoodcorner.com/pos"
set "USER_DIR=%LOCALAPPDATA%\NawabiPOSProfile"

:: Ping 8.8.8.8 to test internet connectivity
ping -n 1 8.8.8.8 >nul 2>&1
if %errorlevel% equ 0 (
    echo [ONLINE] Internet connected. Launching Cloud Hub POS...
    set "TARGET_URL=%ONLINE_URL%"
) else (
    echo [OFFLINE] Internet not detected. Launching 100%% Standalone Offline Kiosk...
    set "TARGET_URL=file:///%LOCAL_KIOSK:\=/%"
)

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --app="%TARGET_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

start "" "%TARGET_URL%"
exit
