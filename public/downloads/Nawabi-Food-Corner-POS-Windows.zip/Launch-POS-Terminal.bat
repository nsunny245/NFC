@echo off
title Nawabi Food Corner - POS Terminal Station
color 0E

echo =======================================================================
echo     NAWABI FOOD CORNER - OFFLINE/ONLINE CASHIER TERMINAL (WIN 7-11)
echo =======================================================================
echo.
echo Checking for hardware-accelerated Chrome/Edge kiosk engine...

set "POS_URL=https://nawabifoodcorner.com/pos"
set "USER_DIR=%LOCALAPPDATA%\NawabiPOSProfile"

:: Check Google Chrome (64-bit, 32-bit, LocalAppData)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%POS_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%POS_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --app="%POS_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

:: Check Microsoft Edge
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%POS_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%POS_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

:: Check Brave Browser
if exist "%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe" (
    start "" "%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe" --app="%POS_URL%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

:: Fallback to Windows default browser or local touch runner
start "" "%POS_URL%"
exit
