@echo off
title Nawabi Food Corner - Standalone Offline POS Station
color 0E

echo =======================================================================
echo     NAWABI FOOD CORNER - STANDALONE OFFLINE POS (WIN 7-11)
echo =======================================================================
echo.
echo Launching 100%% Standalone Offline Cashier Register...
echo (All 17 live menu categories, 88 dishes, offline cart & 80mm thermal receipt)
echo.

set "LOCAL_KIOSK=%~dp0Nawabi-Food-Corner-POS.html"
set "USER_DIR=%LOCALAPPDATA%\NawabiPOSProfile"

:: Launch in Google Chrome App Window Mode if available
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%LOCAL_KIOSK:\=/%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="file:///%LOCAL_KIOSK:\=/%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --app="file:///%LOCAL_KIOSK:\=/%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

:: Launch in Microsoft Edge App Window Mode if available
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%LOCAL_KIOSK:\=/%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%LOCAL_KIOSK:\=/%" --user-data-dir="%USER_DIR%" --start-maximized --disable-translate --no-default-browser-check
    exit
)

:: Fallback to Windows default browser
start "" "%LOCAL_KIOSK%"
exit
